#ifndef REPORTES_H_INCLUDED
#define REPORTES_H_INCLUDED

void menu_reportes();
void recaudacion_mensual();
void venta_mayor_ganancia();
void stock_joven();
void ver_listado_personas();
void buscar_persona_dni();
void ver_venta_detalle();

#endif // REPORTES_H_INCLUDED
