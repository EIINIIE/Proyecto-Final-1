#ifndef AUTOS_DISPONIBLES_H_INCLUDED
#define AUTOS_DISPONIBLES_H_INCLUDED

#include "auto.h"

void mostrar_todos_autos_disponibles();
void mostrar_un_auto(Auto a);
void mostrar_auto_recursivo( FILE* file,  int pos, int total);

#endif // AUTOS_DISPONIBLES_H_INCLUDED
