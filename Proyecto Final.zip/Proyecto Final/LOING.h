#ifndef LOING_H_INCLUDED
#define LOING_H_INCLUDED

// ------- Prototipos P blicos -------
void menu_login();
void login_empresa();
void login_administrador();

#endif // LOING_H_INCLUDED
